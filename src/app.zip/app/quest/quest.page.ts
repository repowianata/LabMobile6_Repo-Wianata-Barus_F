import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quest',
  templateUrl: './quest.page.html',
  styleUrls: ['./quest.page.scss'],
})
export class QuestPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
